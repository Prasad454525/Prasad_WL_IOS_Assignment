//
//  Coordinator.swift
//  TheMovieDB
//
//  Created by user326 on 6/26/21..
//

import UIKit

protocol Coordinator {
    var navigationController: UINavigationController { get set }
    func getViewController() -> UIViewController
    func show(present: Bool)
}
