//
//  DictionaryExtensions.swift
//  TheMovieDB
//
//  Created by user326 on 6/26/21..
//

import Foundation

extension Dictionary {
    mutating func append(dict: [Key: Value]){
        for (k, v) in dict {
            updateValue(v, forKey: k)
        }
    }
}
