//
//  LoadingCell.swift
//  TheMovieDB
//
//  Created by user326 on 6/26/21..
//

import UIKit

class LoadingCell: UITableViewCell {
    static let cellIdentifier = String(describing: LoadingCell.self)
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
}
