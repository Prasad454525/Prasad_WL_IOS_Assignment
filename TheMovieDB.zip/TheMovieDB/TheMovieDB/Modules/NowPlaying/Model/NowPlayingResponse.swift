//
//  NowPlayingResponse.swift
//  TheMovieDB
//Created by user326 on 6/26/21..
//

import Foundation

struct NowPlayingResponse: Codable {
    var movies: [Movie]
    var totalPages: Int

    enum CodingKeys: String, CodingKey {
        case movies = "results"
        case totalPages = "total_pages"
    }
}
