//
//  Alert.swift
//  TheMovieDB
//
//  Created by user326 on 6/26/21..
//

import Foundation

struct AlertAction {
    let buttonTitle: String
    let handler: (() -> Void)?
}

struct SingleButtonAlert {
    let title: String
    let message: String?
    let action: AlertAction
}
