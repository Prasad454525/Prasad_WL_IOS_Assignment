//
//  URLSessionProtocol.swift
//  TheMovieDB
//
//  Created by user326 on 6/26/21..
import Foundation

protocol URLSessionProtocol {
    func dataTask(request: URLRequest, completionHandler: @escaping DataTaskResult) -> URLSessionDataTask
}
