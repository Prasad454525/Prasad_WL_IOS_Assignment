//
//  URLSessionExtensions.swift
//  TheMovieDB
//
//  Created by user326 on 6/26/21..
//

import Foundation

extension URLSession: URLSessionProtocol {
    func dataTask(request: URLRequest, completionHandler: @escaping DataTaskResult) -> URLSessionDataTask {
        return dataTask(with: request, completionHandler: completionHandler)
    }
}
