//
//  Typealias.swift
//  TheMovieDB
//
//  Created by user326 on 6/26/21..

import Foundation

typealias RequestHeaders = [String: String]
typealias DataTaskResult = (Data?, URLResponse?, Error?) -> ()
