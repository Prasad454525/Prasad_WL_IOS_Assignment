//
//  Mock.swift
//  TheMovieDBTests
//
//  Created by user326 on 6/26/21..
import Foundation
@testable import TheMovieDB

internal extension Movie {
    static func getMockMovie() -> Movie {
        return Movie(id: 1, title: "Titanic", overview: "Overview text", poster: "1.jpg", voteAverage: 8.7)
    }
}

internal extension NowPlayingResponse {
    static func getMockNowPlayingResponse () -> NowPlayingResponse {
        return NowPlayingResponse(movies: [Movie.getMockMovie()], totalPages: 1)
    }
}
